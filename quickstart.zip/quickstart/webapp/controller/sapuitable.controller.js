var oSerialNumberLinkReport;
jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");
sap.ui.define([
		'sap/ui/core/mvc/Controller','sap/ui/core/format/DateFormat',
		'sap/ui/model/json/JSONModel'
	], function(Controller, DateFormat, JSONModel) {
	"use strict";

	var PageController = Controller.extend("quickapp.controller.sapuitable", { 
        onInit: function() {
			oSerialNumberLinkReport = this;
           /* var model = new sap.ui.model.json.JSONModel();
            model.setData([{test:"test1"},{test:"test2"}]);
            this.getView().setModel(model);*/
        },  
		onAfterRendering : function() {
			oSerialNumberLinkReport.callRestAPI();
		 },
		onPress: function (evt) {
			jQuery.sap.require("sap.m.MessageToast");
			sap.m.MessageToast.show(evt.getSource().getId() + " Pressed");
		},
		_onTableUpdateFinished: function(oEvent){
			this.getView().byId("idTable").setHeaderText("New Header Text");
		},
		callRestAPI : function(){
			let response = '';
			$.get("http://localhost:3000/getLPList", function (data) {
				//response=JSON.stringify(data);
			//	response = JSON.parse(response);
				var model = new sap.ui.model.json.JSONModel();
			   // model.setData([{test:"test1"},{test:"test2"}]);
				model.setData(data);        
				oSerialNumberLinkReport.getView().setModel(model);
			});
			
		}
	});

	return PageController;

});