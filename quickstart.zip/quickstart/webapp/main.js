let express=require("express");
let mysql=require("mysql");
let cors = require("cors");
let app=express();
app.use(express.json());
app.use(cors());
//create connection
/*et con=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"root",
    database:"RITS1"
});
*/
//connect
con.connect((err)=>{
if(err)
{
    console.log(err);
}
else{
    console.log("connected...!");
}
})


/*
//create DB
app.get('/createdb',(req,res)=>{
    let sql='create database if not exists RITS1'
    con.query(sql,(err,res)=>{
        if(err)
        {
            console.log(err);
        }
        else{
           
            console.log("database created");
        }
    })
})
*/
/*
//create table 

app.get('/createtable',(req,res)=>{
    let sql=`create table downtime(
        Handle  varchar(100) ,
        Event varchar(40),
        Resource varchar(30),
        Resource_DownTime date,
        Resource_UpTime date,
        Resource_MeanTime integer,
        CreatedDateTime date,
        Active integer,
        UNSCH_REF varchar(20),
        ENABLE_REF varchar(20),
        ReasonCode varchar(20)
        )`
    con.query(sql,(err,result)=>{
        if(err)
        {
            console.log(err);
        }
        else{
            console.log(result);
            console.log("table created");
            res.send("table created...")
        }
    })
})
*/
/*
//insert the data

app.post('/post',(req,res)=>{
    var  Handle=req.body.Handle;
    let  Event=req.body.Event;
    let  Resource=req.body.Resource;
    let  Resource_DownTime=req.body.Resource_DownTime;
    let  Resource_UpTime=req.body.Resource_UpTime;
    let  Resource_MeanTime=req.body.Resource_MeanTime;
    var  CreatedDateTime=req.body.CreatedDateTime;
    let  Active=req.body.Active;
    let  UNSCH_REF=req.body.UNSCH_REF;
    let  ENABLE_REF=req.body.ENABLE_REF;
    let  ReasonCode=req.body.ReasonCode;
    var Handle="EventBO:"+Event+","+""+Resource
    var CreatedDateTime= new Date();

con.query('insert into downtime values(?,?,?,?,?,?,?,?,?,?,?)',[Handle,Event,
        Resource,Resource_DownTime,Resource_UpTime,Resource_MeanTime,
        CreatedDateTime,Active,UNSCH_REF,ENABLE_REF,ReasonCode],(err,result)=>{
            if(err)
            {
                console.log(err);
            }
            else {
                res.send("POSTED")
            }
        })
    })
*/   
/*
//update data

app.put('/put',(req,res)=>{
let Event_id=req.params.id;
var  Handle=req.body.Handle;
let  Event=req.body.Event;
let  Resource=req.body.Resource;
let  Resource_DownTime=req.body.Resource_DownTime;
let  Resource_UpTime=req.body.Resource_UpTime;
let  Resource_MeanTime=req.body.Resource_MeanTime;
let  CreatedDateTime=req.body.CreatedDateTime;
let  Active=req.body.Active;
let  UNSCH_REF=req.body.UNSCH_REF;
let  ENABLE_REF=req.body.ENABLE_REF;
let  ReasonCode=req.body.ReasonCode;

con.query(`update Event_Table set Handle=?, Event=?,Resource=?,Resource_DownTime=?,Resource_UpTime=?,Resource_MeanTime=?,CreatedDateTime=?,
Active=?,TriggeringTag3=?,UNSCH_REF=?,
ENABLE_REF=?,ReasonCode=? where id=?`,[Handle,Event,Resource,Resource_DownTime,Resource_UpTime,Resource_MeanTime,
CreatedDateTime,Active,UNSCH_REF,ENABLE_REF,ReasonCode],(err,result)=>{
    if(err)
    {
        console.log(err);
    }
    else{
        res.send("updated")
    }
})
})
*/




//get all table detailes

app.get('/get',(req,res)=>{
   
		 res.send("Sucess.");
   
  
})

/*
//retrieve 
app.get('/retrieve',(req,res)=>{
    let retrievesql=`select * from DOWNTIME where
    Resource='[Param.1]' and CreatedDateTime BETWEEN '[Param.2]' AND '[Param.3]'`
    con.query(retrievesql,(err,result)=>{
 if(err)
 {
     console.log(err);
 }
 else{
     res.send(result)
 }
    })
   
 })
 
/*
//alter table 

app.get('/altertable',(req,res)=>{
    let alter_sql=`alter table downtime modify Resource_DownTime date,
                    modify Resource_UpTime date`
    con.query(alter_sql,(err,result)=>{
        if(err)
        {
            console.log(err);
        }
        else{
            console.log(result);
        }
    })
})

*/

app.listen('8000',()=>{
    console.log('server started on port 8000');
})


